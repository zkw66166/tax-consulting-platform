﻿import React, { useState } from 'react';
import { MessageCircle, FileText, Shield, Calculator, BarChart3, Users, Search, Bell, Settings, ChevronRight, TrendingUp, AlertTriangle, CheckCircle, Download, Eye, BookOpen, MapPin, Phone, Building, DollarSign, PieChart, Activity, RefreshCw, Edit, Plus, Heart, Share2, ArrowDown } from 'lucide-react';

// 简化版测试组件
function TailwindTest() {
    return (
        <div className="bg-blue-500 text-white p-4 mb-4 rounded-lg">
            <h2 className="text-xl font-bold">✅ Tailwind CSS 已正常工作！</h2>
            <p className="mt-2">如果您看到蓝色背景和白色文字，说明样式配置成功。</p>
        </div>
    );
}

function TaxConsultingPlatform() {
    const [activeTab, setActiveTab] = useState('dashboard');
    const [chatMessages, setChatMessages] = useState([
        { type: 'ai', content: '您好！我是您的AI税务顾问，请问今天需要什么帮助？' }
    ]);
    const [userInput, setUserInput] = useState('');

    const navigationItems = [
        { id: 'dashboard', label: '智能咨询台', icon: MessageCircle },
        { id: 'health', label: '税务体检', icon: Shield },
        { id: 'planning', label: '筹划方案', icon: Calculator },
        { id: 'compliance', label: '合规监控', icon: AlertTriangle },
        { id: 'filing', label: '申报服务', icon: FileText },
        { id: 'analytics', label: '数据分析', icon: BarChart3 },
        { id: 'knowledge', label: '知识库', icon: Search },
        { id: 'profile', label: '企业档案', icon: Users }
    ];

    const handleSendMessage = () => {
        if (userInput.trim()) {
            setChatMessages([...chatMessages,
            { type: 'user', content: userInput },
            { type: 'ai', content: `根据您的问题"${userInput}"，我建议您查看税务筹划方案。基于您的行业特点，我发现了3个优化机会...` }
            ]);
            setUserInput('');
        }
    };

    const renderDashboard = () => (
        <div className="space-y-6">
            <TailwindTest />

            <div className="bg-gradient-to-r from-blue-500 to-purple-600 text-white p-6 rounded-lg">
                <h2 className="text-2xl font-bold mb-2">智能税务咨询台</h2>
                <p className="text-blue-100">24小时AI税务顾问，随时为您解答税务问题</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 bg-white rounded-lg shadow-sm border">
                    <div className="p-4 border-b">
                        <h3 className="font-semibold">AI对话咨询</h3>
                    </div>
                    <div className="h-96 overflow-y-auto p-4 space-y-4">
                        {chatMessages.map((msg, idx) => (
                            <div key={idx} className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                                <div className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${msg.type === 'user'
                                        ? 'bg-blue-500 text-white'
                                        : 'bg-gray-100 text-gray-800'
                                    }`}>
                                    {msg.content}
                                </div>
                            </div>
                        ))}
                    </div>
                    <div className="p-4 border-t">
                        <div className="flex space-x-2">
                            <input
                                type="text"
                                value={userInput}
                                onChange={(e) => setUserInput(e.target.value)}
                                placeholder="请输入您的税务问题..."
                                className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                            />
                            <button
                                onClick={handleSendMessage}
                                className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            >
                                发送
                            </button>
                        </div>
                    </div>
                </div>

                <div className="space-y-4">
                    <div className="bg-white rounded-lg shadow-sm border p-4">
                        <h3 className="font-semibold mb-3">快速功能</h3>
                        <div className="space-y-2">
                            <button
                                onClick={() => setActiveTab('health')}
                                className="w-full text-left p-3 rounded-lg border hover:bg-gray-50 flex items-center justify-between"
                            >
                                <span className="flex items-center space-x-2">
                                    <Shield className="w-4 h-4 text-green-500" />
                                    <span>税务体检</span>
                                </span>
                                <ChevronRight className="w-4 h-4" />
                            </button>
                            <button
                                onClick={() => setActiveTab('planning')}
                                className="w-full text-left p-3 rounded-lg border hover:bg-gray-50 flex items-center justify-between"
                            >
                                <span className="flex items-center space-x-2">
                                    <Calculator className="w-4 h-4 text-blue-500" />
                                    <span>生成筹划方案</span>
                                </span>
                                <ChevronRight className="w-4 h-4" />
                            </button>
                        </div>
                    </div>

                    <div className="bg-white rounded-lg shadow-sm border p-4">
                        <h3 className="font-semibold mb-3">今日提醒</h3>
                        <div className="space-y-2 text-sm">
                            <div className="flex items-center space-x-2 text-orange-600">
                                <Bell className="w-4 h-4" />
                                <span>增值税申报截止还有3天</span>
                            </div>
                            <div className="flex items-center space-x-2 text-blue-600">
                                <TrendingUp className="w-4 h-4" />
                                <span>新政策：研发费用扣除比例调整</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );

    const renderOtherTabs = () => (
        <div className="bg-white rounded-lg shadow-sm border p-8 text-center">
            <h2 className="text-2xl font-bold mb-4">功能开发中</h2>
            <p className="text-gray-600">该功能正在开发中，敬请期待...</p>
            <button
                onClick={() => setActiveTab('dashboard')}
                className="mt-4 px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600"
            >
                返回首页
            </button>
        </div>
    );

    return (
        <div className="min-h-screen bg-gray-50">
            {/* 顶部导航栏 */}
            <header className="bg-white shadow-sm border-b">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex justify-between items-center h-16">
                        <div className="flex items-center space-x-4">
                            <Calculator className="w-8 h-8 text-blue-500" />
                            <h1 className="text-xl font-bold text-gray-900">智税通AI</h1>
                        </div>
                        <div className="flex items-center space-x-4">
                            <button className="p-2 text-gray-400 hover:text-gray-600">
                                <Bell className="w-5 h-5" />
                            </button>
                            <button className="p-2 text-gray-400 hover:text-gray-600">
                                <Settings className="w-5 h-5" />
                            </button>
                            <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-medium">
                                张
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                <div className="flex gap-8">
                    {/* 侧边栏 */}
                    <aside className="w-64 flex-shrink-0">
                        <nav className="bg-white rounded-lg shadow-sm border">
                            <div className="p-4">
                                <h2 className="text-sm font-medium text-gray-500 uppercase tracking-wide">功能导航</h2>
                            </div>
                            <ul className="space-y-1 p-2">
                                {navigationItems.map((item) => {
                                    const Icon = item.icon;
                                    return (
                                        <li key={item.id}>
                                            <button
                                                onClick={() => setActiveTab(item.id)}
                                                className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors ${activeTab === item.id
                                                        ? 'bg-blue-500 text-white'
                                                        : 'text-gray-700 hover:bg-gray-100'
                                                    }`}
                                            >
                                                <Icon className="w-5 h-5" />
                                                <span>{item.label}</span>
                                            </button>
                                        </li>
                                    );
                                })}
                            </ul>
                        </nav>
                    </aside>

                    {/* 主内容区 */}
                    <main className="flex-1">
                        {activeTab === 'dashboard' ? renderDashboard() : renderOtherTabs()}
                    </main>
                </div>
            </div>
        </div>
    );
}

export default TaxConsultingPlatform;