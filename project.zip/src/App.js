﻿import React, { useState } from 'react';
import { MessageCircle, FileText, Shield, Calculator, BarChart3, Users, Search, Bell, Settings, ChevronRight, TrendingUp, AlertTriangle, CheckCircle, Upload, Download, Eye, BookOpen, Calendar, Clock, MapPin, Phone, Mail, Building, DollarSign, PieChart, Activity, Filter, RefreshCw, Edit, Plus, Trash2, Star, Heart, Share2, ArrowUp, ArrowDown, Minus } from 'lucide-react';

function TaxConsultingPlatform() {
    const [activeTab, setActiveTab] = useState('dashboard');
    const [chatMessages, setChatMessages] = useState([
        { type: 'ai', content: '您好！我是您的AI税务顾问，请问今天需要什么帮助？' }
    ]);
    const [userInput, setUserInput] = useState('');
    const [selectedCompany, setSelectedCompany] = useState('北京xx科技有限公司');

    const navigationItems = [
        { id: 'dashboard', label: '智能咨询台', icon: MessageCircle },
        { id: 'health', label: '税务体检', icon: Shield },
        { id: 'planning', label: '筹划方案', icon: Calculator },
        { id: 'compliance', label: '合规监控', icon: AlertTriangle },
        { id: 'filing', label: '申报服务', icon: FileText },
        { id: 'analytics', label: '数据分析', icon: BarChart3 },
        { id: 'knowledge', label: '知识库', icon: Search },
        { id: 'profile', label: '企业档案', icon: Users }
    ];

    const handleSendMessage = () => {
        if (userInput.trim()) {
            setChatMessages([...chatMessages,
            { type: 'user', content: userInput },
            { type: 'ai', content: `根据您的问题"${userInput}"，我建议您查看税务筹划方案。基于您的行业特点，我发现了3个优化机会...` }
            ]);
            setUserInput('');
        }
    };

    // 智能咨询台页面
    const renderDashboard = () => (
        <div className="space-y-6">
            <div className="bg-gradient-to-r from-blue-500 to-purple-600 text-white p-6 rounded-lg">
                <h2 className="text-2xl font-bold mb-2">智能税务咨询台</h2>
                <p className="text-blue-100">24小时AI税务顾问，随时为您解答税务问题</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 bg-white rounded-lg shadow-sm border">
                    <div className="p-4 border-b">
                        <h3 className="font-semibold flex items-center">
                            <MessageCircle className="w-5 h-5 mr-2" />
                            AI对话咨询
                        </h3>
                    </div>
                    <div className="h-96 overflow-y-auto p-4 space-y-4">
                        {chatMessages.map((msg, idx) => (
                            <div key={idx} className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                                <div className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${msg.type === 'user'
                                        ? 'bg-blue-500 text-white'
                                        : 'bg-gray-100 text-gray-800'
                                    }`}>
                                    {msg.content}
                                </div>
                            </div>
                        ))}
                    </div>
                    <div className="p-4 border-t">
                        <div className="flex space-x-2">
                            <input
                                type="text"
                                value={userInput}
                                onChange={(e) => setUserInput(e.target.value)}
                                placeholder="请输入您的税务问题..."
                                className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                            />
                            <button
                                onClick={handleSendMessage}
                                className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600"
                            >
                                发送
                            </button>
                        </div>
                    </div>
                </div>

                <div className="space-y-4">
                    <div className="bg-white rounded-lg shadow-sm border p-4">
                        <h3 className="font-semibold mb-3">快速功能</h3>
                        <div className="space-y-2">
                            <button
                                onClick={() => setActiveTab('health')}
                                className="w-full text-left p-3 rounded-lg border hover:bg-gray-50 flex items-center justify-between"
                            >
                                <span className="flex items-center space-x-2">
                                    <Shield className="w-4 h-4 text-green-500" />
                                    <span>税务体检</span>
                                </span>
                                <ChevronRight className="w-4 h-4" />
                            </button>
                            <button
                                onClick={() => setActiveTab('planning')}
                                className="w-full text-left p-3 rounded-lg border hover:bg-gray-50 flex items-center justify-between"
                            >
                                <span className="flex items-center space-x-2">
                                    <Calculator className="w-4 h-4 text-blue-500" />
                                    <span>生成筹划方案</span>
                                </span>
                                <ChevronRight className="w-4 h-4" />
                            </button>
                        </div>
                    </div>

                    <div className="bg-white rounded-lg shadow-sm border p-4">
                        <h3 className="font-semibold mb-3">今日提醒</h3>
                        <div className="space-y-2 text-sm">
                            <div className="flex items-center space-x-2 text-orange-600">
                                <Bell className="w-4 h-4" />
                                <span>增值税申报截止还有3天</span>
                            </div>
                            <div className="flex items-center space-x-2 text-blue-600">
                                <TrendingUp className="w-4 h-4" />
                                <span>新政策：研发费用扣除比例调整</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );

    // 税务体检页面
    const renderHealthCheck = () => (
        <div className="space-y-6">
            <div className="bg-gradient-to-r from-green-500 to-emerald-600 text-white p-6 rounded-lg">
                <h2 className="text-2xl font-bold mb-2">税务体检中心</h2>
                <p className="text-green-100">全面检查企业税务健康状况，发现潜在风险</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-4">
                    <div className="bg-white rounded-lg shadow-sm border p-6">
                        <h3 className="text-lg font-semibold mb-4 flex items-center">
                            <Shield className="w-5 h-5 mr-2 text-green-500" />
                            体检报告概览
                        </h3>
                        <div className="grid grid-cols-2 gap-4">
                            <div className="text-center p-4 bg-green-50 rounded-lg">
                                <div className="text-2xl font-bold text-green-600">92</div>
                                <div className="text-sm text-gray-600">健康评分</div>
                            </div>
                            <div className="text-center p-4 bg-orange-50 rounded-lg">
                                <div className="text-2xl font-bold text-orange-600">3</div>
                                <div className="text-sm text-gray-600">待处理风险</div>
                            </div>
                        </div>
                    </div>

                    <div className="bg-white rounded-lg shadow-sm border p-6">
                        <h3 className="text-lg font-semibold mb-4">风险详情</h3>
                        <div className="space-y-3">
                            <div className="flex items-center justify-between p-3 border-l-4 border-red-400 bg-red-50">
                                <div>
                                    <div className="font-medium text-red-800">增值税进项抵扣异常</div>
                                    <div className="text-sm text-red-600">进项税额占比过高，可能存在虚开风险</div>
                                </div>
                                <AlertTriangle className="w-5 h-5 text-red-500" />
                            </div>
                            <div className="flex items-center justify-between p-3 border-l-4 border-yellow-400 bg-yellow-50">
                                <div>
                                    <div className="font-medium text-yellow-800">企业所得税预缴不足</div>
                                    <div className="text-sm text-yellow-600">建议调整预缴税额避免年末补税</div>
                                </div>
                                <AlertTriangle className="w-5 h-5 text-yellow-500" />
                            </div>
                            <div className="flex items-center justify-between p-3 border-l-4 border-orange-400 bg-orange-50">
                                <div>
                                    <div className="font-medium text-orange-800">发票管理待优化</div>
                                    <div className="text-sm text-orange-600">建议建立更完善的发票管理制度</div>
                                </div>
                                <AlertTriangle className="w-5 h-5 text-orange-500" />
                            </div>
                        </div>
                    </div>
                </div>

                <div className="space-y-4">
                    <div className="bg-white rounded-lg shadow-sm border p-4">
                        <h3 className="font-semibold mb-3">快速操作</h3>
                        <div className="space-y-2">
                            <button className="w-full p-3 text-left border rounded-lg hover:bg-gray-50">
                                <RefreshCw className="w-4 h-4 inline mr-2" />
                                重新体检
                            </button>
                            <button className="w-full p-3 text-left border rounded-lg hover:bg-gray-50">
                                <Download className="w-4 h-4 inline mr-2" />
                                下载报告
                            </button>
                            <button className="w-full p-3 text-left border rounded-lg hover:bg-gray-50">
                                <Eye className="w-4 h-4 inline mr-2" />
                                查看历史
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );

    // 筹划方案页面
    const renderPlanning = () => (
        <div className="space-y-6">
            <div className="bg-gradient-to-r from-purple-500 to-pink-600 text-white p-6 rounded-lg">
                <h2 className="text-2xl font-bold mb-2">税务筹划方案</h2>
                <p className="text-purple-100">智能生成个性化税务筹划方案，合法节税</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-4">
                    <div className="bg-white rounded-lg shadow-sm border p-6">
                        <h3 className="text-lg font-semibold mb-4 flex items-center">
                            <Calculator className="w-5 h-5 mr-2 text-purple-500" />
                            推荐方案
                        </h3>
                        <div className="space-y-4">
                            <div className="border rounded-lg p-4 hover:bg-gray-50">
                                <div className="flex justify-between items-start mb-2">
                                    <h4 className="font-medium">研发费用加计扣除优化</h4>
                                    <span className="text-green-600 font-semibold">预计节税: ¥125,000</span>
                                </div>
                                <p className="text-sm text-gray-600 mb-3">
                                    通过规范研发费用归集和管理，充分享受175%加计扣除政策
                                </p>
                                <div className="flex space-x-2">
                                    <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded">推荐</span>
                                    <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">低风险</span>
                                </div>
                            </div>

                            <div className="border rounded-lg p-4 hover:bg-gray-50">
                                <div className="flex justify-between items-start mb-2">
                                    <h4 className="font-medium">小微企业所得税优惠</h4>
                                    <span className="text-green-600 font-semibold">预计节税: ¥89,000</span>
                                </div>
                                <p className="text-sm text-gray-600 mb-3">
                                    合理分拆业务享受小微企业所得税优惠政策
                                </p>
                                <div className="flex space-x-2">
                                    <span className="px-2 py-1 bg-yellow-100 text-yellow-800 text-xs rounded">中等收益</span>
                                    <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">中等风险</span>
                                </div>
                            </div>

                            <div className="border rounded-lg p-4 hover:bg-gray-50">
                                <div className="flex justify-between items-start mb-2">
                                    <h4 className="font-medium">增值税进项税优化</h4>
                                    <span className="text-green-600 font-semibold">预计节税: ¥56,000</span>
                                </div>
                                <p className="text-sm text-gray-600 mb-3">
                                    完善进项税管理制度，提高抵扣效率
                                </p>
                                <div className="flex space-x-2">
                                    <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded">易实施</span>
                                    <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded">低风险</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="space-y-4">
                    <div className="bg-white rounded-lg shadow-sm border p-4">
                        <h3 className="font-semibold mb-3">节税统计</h3>
                        <div className="space-y-3">
                            <div className="flex justify-between">
                                <span>预计年节税额</span>
                                <span className="font-semibold text-green-600">¥270,000</span>
                            </div>
                            <div className="flex justify-between">
                                <span>当前税负率</span>
                                <span>12.5%</span>
                            </div>
                            <div className="flex justify-between">
                                <span>优化后税负率</span>
                                <span className="font-semibold text-green-600">9.8%</span>
                            </div>
                        </div>
                    </div>

                    <div className="bg-white rounded-lg shadow-sm border p-4">
                        <h3 className="font-semibold mb-3">操作建议</h3>
                        <div className="space-y-2 text-sm">
                            <div className="flex items-center space-x-2">
                                <CheckCircle className="w-4 h-4 text-green-500" />
                                <span>立即实施研发费用优化</span>
                            </div>
                            <div className="flex items-center space-x-2">
                                <Clock className="w-4 h-4 text-yellow-500" />
                                <span>月底前完成进项税整理</span>
                            </div>
                            <div className="flex items-center space-x-2">
                                <BookOpen className="w-4 h-4 text-blue-500" />
                                <span>关注最新政策变化</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );

    // 合规监控页面
    const renderCompliance = () => (
        <div className="space-y-6">
            <div className="bg-gradient-to-r from-red-500 to-pink-600 text-white p-6 rounded-lg">
                <h2 className="text-2xl font-bold mb-2">合规监控中心</h2>
                <p className="text-red-100">实时监控税务合规状况，预警潜在风险</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 mb-6">
                <div className="bg-white rounded-lg shadow-sm border p-4 text-center">
                    <div className="text-2xl font-bold text-green-600">正常</div>
                    <div className="text-sm text-gray-600">增值税申报</div>
                </div>
                <div className="bg-white rounded-lg shadow-sm border p-4 text-center">
                    <div className="text-2xl font-bold text-yellow-600">预警</div>
                    <div className="text-sm text-gray-600">企业所得税</div>
                </div>
                <div className="bg-white rounded-lg shadow-sm border p-4 text-center">
                    <div className="text-2xl font-bold text-green-600">正常</div>
                    <div className="text-sm text-gray-600">个人所得税</div>
                </div>
                <div className="bg-white rounded-lg shadow-sm border p-4 text-center">
                    <div className="text-2xl font-bold text-red-600">异常</div>
                    <div className="text-sm text-gray-600">发票管理</div>
                </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm border">
                <div className="p-4 border-b">
                    <h3 className="text-lg font-semibold">风险监控</h3>
                </div>
                <div className="p-4">
                    <div className="space-y-4">
                        <div className="flex items-center justify-between p-4 border-l-4 border-red-400 bg-red-50 rounded">
                            <div>
                                <div className="font-medium text-red-800">发票开具异常</div>
                                <div className="text-sm text-red-600">检测到连续开具相同金额发票</div>
                                <div className="text-xs text-gray-500 mt-1">2024-06-12 14:30</div>
                            </div>
                            <div className="flex space-x-2">
                                <button className="px-3 py-1 bg-red-600 text-white text-sm rounded hover:bg-red-700">
                                    处理
                                </button>
                                <button className="px-3 py-1 border border-red-600 text-red-600 text-sm rounded hover:bg-red-50">
                                    详情
                                </button>
                            </div>
                        </div>

                        <div className="flex items-center justify-between p-4 border-l-4 border-yellow-400 bg-yellow-50 rounded">
                            <div>
                                <div className="font-medium text-yellow-800">申报期限提醒</div>
                                <div className="text-sm text-yellow-600">增值税申报将在3天后到期</div>
                                <div className="text-xs text-gray-500 mt-1">2024-06-12 09:00</div>
                            </div>
                            <div className="flex space-x-2">
                                <button className="px-3 py-1 bg-yellow-600 text-white text-sm rounded hover:bg-yellow-700">
                                    申报
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );

    // 申报服务页面
    const renderFiling = () => (
        <div className="space-y-6">
            <div className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white p-6 rounded-lg">
                <h2 className="text-2xl font-bold mb-2">申报服务中心</h2>
                <p className="text-indigo-100">智能化税务申报，确保准确及时</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-4">
                    <div className="bg-white rounded-lg shadow-sm border p-6">
                        <h3 className="text-lg font-semibold mb-4">本月申报任务</h3>
                        <div className="space-y-3">
                            <div className="flex items-center justify-between p-4 border rounded-lg">
                                <div>
                                    <div className="font-medium">增值税及附加税申报</div>
                                    <div className="text-sm text-gray-600">申报期限: 2024-06-15</div>
                                </div>
                                <div className="flex items-center space-x-2">
                                    <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded">已完成</span>
                                    <button className="px-3 py-1 bg-blue-600 text-white text-sm rounded">
                                        查看
                                    </button>
                                </div>
                            </div>

                            <div className="flex items-center justify-between p-4 border rounded-lg">
                                <div>
                                    <div className="font-medium">企业所得税月报</div>
                                    <div className="text-sm text-gray-600">申报期限: 2024-06-15</div>
                                </div>
                                <div className="flex items-center space-x-2">
                                    <span className="px-2 py-1 bg-yellow-100 text-yellow-800 text-xs rounded">待申报</span>
                                    <button className="px-3 py-1 bg-green-600 text-white text-sm rounded">
                                        申报
                                    </button>
                                </div>
                            </div>

                            <div className="flex items-center justify-between p-4 border rounded-lg">
                                <div>
                                    <div className="font-medium">个人所得税申报</div>
                                    <div className="text-sm text-gray-600">申报期限: 2024-06-15</div>
                                </div>
                                <div className="flex items-center space-x-2">
                                    <span className="px-2 py-1 bg-gray-100 text-gray-800 text-xs rounded">未开始</span>
                                    <button className="px-3 py-1 bg-gray-400 text-white text-sm rounded">
                                        准备
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="space-y-4">
                    <div className="bg-white rounded-lg shadow-sm border p-4">
                        <h3 className="font-semibold mb-3">申报统计</h3>
                        <div className="space-y-2">
                            <div className="flex justify-between">
                                <span>本月已申报</span>
                                <span className="font-semibold">3/5</span>
                            </div>
                            <div className="flex justify-between">
                                <span>按时申报率</span>
                                <span className="font-semibold text-green-600">100%</span>
                            </div>
                            <div className="flex justify-between">
                                <span>本月税款</span>
                                <span className="font-semibold">¥45,680</span>
                            </div>
                        </div>
                    </div>

                    <div className="bg-white rounded-lg shadow-sm border p-4">
                        <h3 className="font-semibold mb-3">快速申报</h3>
                        <div className="space-y-2">
                            <button className="w-full p-3 text-left border rounded-lg hover:bg-gray-50">
                                <FileText className="w-4 h-4 inline mr-2" />
                                增值税申报
                            </button>
                            <button className="w-full p-3 text-left border rounded-lg hover:bg-gray-50">
                                <Calculator className="w-4 h-4 inline mr-2" />
                                所得税申报
                            </button>
                            <button className="w-full p-3 text-left border rounded-lg hover:bg-gray-50">
                                <Users className="w-4 h-4 inline mr-2" />
                                个税申报
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );

    // 数据分析页面
    const renderAnalytics = () => (
        <div className="space-y-6">
            <div className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white p-6 rounded-lg">
                <h2 className="text-2xl font-bold mb-2">数据分析中心</h2>
                <p className="text-cyan-100">深度分析税务数据，洞察业务趋势</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white rounded-lg shadow-sm border p-6">
                    <h3 className="text-lg font-semibold mb-4 flex items-center">
                        <BarChart3 className="w-5 h-5 mr-2 text-blue-500" />
                        税负分析
                    </h3>
                    <div className="h-64 flex items-center justify-center border-2 border-dashed border-gray-300 rounded-lg">
                        <div className="text-center">
                            <BarChart3 className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                            <p className="text-gray-500">税负趋势图表</p>
                        </div>
                    </div>
                </div>

                <div className="bg-white rounded-lg shadow-sm border p-6">
                    <h3 className="text-lg font-semibold mb-4 flex items-center">
                        <PieChart className="w-5 h-5 mr-2 text-green-500" />
                        税种构成
                    </h3>
                    <div className="h-64 flex items-center justify-center border-2 border-dashed border-gray-300 rounded-lg">
                        <div className="text-center">
                            <PieChart className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                            <p className="text-gray-500">税种分布饼图</p>
                        </div>
                    </div>
                </div>

                <div className="bg-white rounded-lg shadow-sm border p-6">
                    <h3 className="text-lg font-semibold mb-4 flex items-center">
                        <TrendingUp className="w-5 h-5 mr-2 text-purple-500" />
                        收入趋势
                    </h3>
                    <div className="h-64 flex items-center justify-center border-2 border-dashed border-gray-300 rounded-lg">
                        <div className="text-center">
                            <TrendingUp className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                            <p className="text-gray-500">收入趋势分析</p>
                        </div>
                    </div>
                </div>

                <div className="bg-white rounded-lg shadow-sm border p-6">
                    <h3 className="text-lg font-semibold mb-4 flex items-center">
                        <Activity className="w-5 h-5 mr-2 text-orange-500" />
                        关键指标
                    </h3>
                    <div className="space-y-4">
                        <div className="flex justify-between items-center">
                            <span>平均税负率</span>
                            <span className="font-semibold">12.5%</span>
                        </div>
                        <div className="flex justify-between items-center">
                            <span>同比变化</span>
                            <span className="font-semibold text-green-600">-2.3%</span>
                        </div>
                        <div className="flex justify-between items-center">
                            <span>行业排名</span>
                            <span className="font-semibold">前25%</span>
                        </div>
                        <div className="flex justify-between items-center">
                            <span>合规评分</span>
                            <span className="font-semibold text-green-600">92分</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );

    // 知识库页面
    const renderKnowledge = () => (
        <div className="space-y-6">
            <div className="bg-gradient-to-r from-emerald-500 to-teal-600 text-white p-6 rounded-lg">
                <h2 className="text-2xl font-bold mb-2">税务知识库</h2>
                <p className="text-emerald-100">海量税务知识，智能检索，专业解答</p>
            </div>

            <div className="bg-white rounded-lg shadow-sm border p-6">
                <div className="flex space-x-4 mb-6">
                    <div className="flex-1">
                        <input
                            type="text"
                            placeholder="搜索税务政策、法规、案例..."
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                    </div>
                    <button className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                        <Search className="w-5 h-5" />
                    </button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <div className="lg:col-span-2 space-y-4">
                        <div className="border rounded-lg p-4">
                            <h4 className="font-medium mb-2">最新政策解读</h4>
                            <p className="text-sm text-gray-600 mb-3">
                                关于进一步实施小微企业所得税优惠政策的公告
                            </p>
                            <div className="flex justify-between items-center">
                                <span className="text-xs text-gray-500">2024-06-10</span>
                                <button className="text-blue-600 text-sm hover:underline">阅读全文</button>
                            </div>
                        </div>

                        <div className="border rounded-lg p-4">
                            <h4 className="font-medium mb-2">研发费用加计扣除指南</h4>
                            <p className="text-sm text-gray-600 mb-3">
                                详解研发费用归集范围及加计扣除操作要点
                            </p>
                            <div className="flex justify-between items-center">
                                <span className="text-xs text-gray-500">2024-06-08</span>
                                <button className="text-blue-600 text-sm hover:underline">阅读全文</button>
                            </div>
                        </div>

                        <div className="border rounded-lg p-4">
                            <h4 className="font-medium mb-2">增值税发票管理办法</h4>
                            <p className="text-sm text-gray-600 mb-3">
                                增值税专用发票和普通发票的开具、使用规范
                            </p>
                            <div className="flex justify-between items-center">
                                <span className="text-xs text-gray-500">2024-06-05</span>
                                <button className="text-blue-600 text-sm hover:underline">阅读全文</button>
                            </div>
                        </div>
                    </div>

                    <div className="space-y-4">
                        <div className="border rounded-lg p-4">
                            <h4 className="font-medium mb-3">热门分类</h4>
                            <div className="space-y-2">
                                <button className="w-full text-left p-2 hover:bg-gray-50 rounded">增值税政策</button>
                                <button className="w-full text-left p-2 hover:bg-gray-50 rounded">所得税优惠</button>
                                <button className="w-full text-left p-2 hover:bg-gray-50 rounded">发票管理</button>
                                <button className="w-full text-left p-2 hover:bg-gray-50 rounded">税务筹划</button>
                                <button className="w-full text-left p-2 hover:bg-gray-50 rounded">合规要求</button>
                            </div>
                        </div>

                        <div className="border rounded-lg p-4">
                            <h4 className="font-medium mb-3">推荐阅读</h4>
                            <div className="space-y-2 text-sm">
                                <div className="flex items-center space-x-2">
                                    <Star className="w-4 h-4 text-yellow-500" />
                                    <span>小规模纳税人转一般纳税人</span>
                                </div>
                                <div className="flex items-center space-x-2">
                                    <Star className="w-4 h-4 text-yellow-500" />
                                    <span>高新技术企业认定条件</span>
                                </div>
                                <div className="flex items-center space-x-2">
                                    <Star className="w-4 h-4 text-yellow-500" />
                                    <span>个人所得税年度汇算</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );

    // 企业档案页面
    const renderProfile = () => (
        <div className="space-y-6">
            <div className="bg-gradient-to-r from-slate-500 to-gray-600 text-white p-6 rounded-lg">
                <h2 className="text-2xl font-bold mb-2">企业档案管理</h2>
                <p className="text-slate-100">管理企业基本信息和税务档案</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-4">
                    <div className="bg-white rounded-lg shadow-sm border p-6">
                        <div className="flex justify-between items-center mb-4">
                            <h3 className="text-lg font-semibold">企业基本信息</h3>
                            <button className="px-3 py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700">
                                <Edit className="w-4 h-4 inline mr-1" />
                                编辑
                            </button>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">企业名称</label>
                                <input
                                    type="text"
                                    value={selectedCompany}
                                    onChange={(e) => setSelectedCompany(e.target.value)}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">统一社会信用代码</label>
                                <input
                                    type="text"
                                    defaultValue="91110000123456789X"
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">法定代表人</label>
                                <input
                                    type="text"
                                    defaultValue="张三"
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">注册资本</label>
                                <input
                                    type="text"
                                    defaultValue="500万元"
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                />
                            </div>
                            <div className="col-span-2">
                                <label className="block text-sm font-medium text-gray-700 mb-1">经营地址</label>
                                <input
                                    type="text"
                                    defaultValue="北京市海淀区中关村南大街XX号XX层"
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                />
                            </div>
                        </div>
                    </div>

                    <div className="bg-white rounded-lg shadow-sm border p-6">
                        <h3 className="text-lg font-semibold mb-4">税务登记信息</h3>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">纳税人识别号</label>
                                <input
                                    type="text"
                                    defaultValue="91110000123456789X"
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">纳税人类型</label>
                                <select className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                                    <option>一般纳税人</option>
                                    <option>小规模纳税人</option>
                                </select>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">主管税务机关</label>
                                <input
                                    type="text"
                                    defaultValue="北京市海淀区税务局"
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">行业分类</label>
                                <input
                                    type="text"
                                    defaultValue="软件和信息技术服务业"
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                />
                            </div>
                        </div>
                    </div>
                </div>

                <div className="space-y-4">
                    <div className="bg-white rounded-lg shadow-sm border p-4">
                        <h3 className="font-semibold mb-3">企业状态</h3>
                        <div className="space-y-2">
                            <div className="flex justify-between">
                                <span>工商状态</span>
                                <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded">正常</span>
                            </div>
                            <div className="flex justify-between">
                                <span>税务状态</span>
                                <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded">正常</span>
                            </div>
                            <div className="flex justify-between">
                                <span>社保状态</span>
                                <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded">正常</span>
                            </div>
                        </div>
                    </div>

                    <div className="bg-white rounded-lg shadow-sm border p-4">
                        <h3 className="font-semibold mb-3">快速操作</h3>
                        <div className="space-y-2">
                            <button className="w-full p-3 text-left border rounded-lg hover:bg-gray-50">
                                <Building className="w-4 h-4 inline mr-2" />
                                企业变更
                            </button>
                            <button className="w-full p-3 text-left border rounded-lg hover:bg-gray-50">
                                <FileText className="w-4 h-4 inline mr-2" />
                                资质证书
                            </button>
                            <button className="w-full p-3 text-left border rounded-lg hover:bg-gray-50">
                                <Users className="w-4 h-4 inline mr-2" />
                                人员管理
                            </button>
                        </div>
                    </div>

                    <div className="bg-white rounded-lg shadow-sm border p-4">
                        <h3 className="font-semibold mb-3">联系信息</h3>
                        <div className="space-y-2 text-sm">
                            <div className="flex items-center space-x-2">
                                <Phone className="w-4 h-4 text-gray-400" />
                                <span>010-12345678</span>
                            </div>
                            <div className="flex items-center space-x-2">
                                <Mail className="w-4 h-4 text-gray-400" />
                                <span>contact@company.com</span>
                            </div>
                            <div className="flex items-center space-x-2">
                                <MapPin className="w-4 h-4 text-gray-400" />
                                <span>北京市海淀区</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );

    // 根据activeTab渲染对应页面
    const renderContent = () => {
        switch (activeTab) {
            case 'dashboard':
                return renderDashboard();
            case 'health':
                return renderHealthCheck();
            case 'planning':
                return renderPlanning();
            case 'compliance':
                return renderCompliance();
            case 'filing':
                return renderFiling();
            case 'analytics':
                return renderAnalytics();
            case 'knowledge':
                return renderKnowledge();
            case 'profile':
                return renderProfile();
            default:
                return renderDashboard();
        }
    };

    return (
        <div className="min-h-screen bg-gray-50">
            {/* 顶部导航栏 */}
            <header className="bg-white shadow-sm border-b sticky top-0 z-10">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex justify-between items-center h-16">
                        <div className="flex items-center space-x-4">
                            <Calculator className="w-8 h-8 text-blue-500" />
                            <h1 className="text-xl font-bold text-gray-900">智税通AI</h1>
                            <div className="hidden md:flex space-x-1">
                                <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">工具</span>
                                <span className="px-2 py-1 bg-gray-100 text-gray-800 text-xs rounded">AI搜索</span>
                                <span className="px-2 py-1 bg-gray-100 text-gray-800 text-xs rounded">AI大模型</span>
                                <span className="px-2 py-1 bg-gray-100 text-gray-800 text-xs rounded">Deepseek</span>
                                <span className="px-2 py-1 bg-gray-100 text-gray-800 text-xs rounded">AI财税</span>
                                <span className="px-2 py-1 bg-gray-100 text-gray-800 text-xs rounded">财税动态</span>
                                <span className="px-2 py-1 bg-gray-100 text-gray-800 text-xs rounded">法规</span>
                                <span className="px-2 py-1 bg-gray-100 text-gray-800 text-xs rounded">系统设置</span>
                            </div>
                        </div>
                        <div className="flex items-center space-x-4">
                            <button className="p-2 text-gray-400 hover:text-gray-600 relative">
                                <Bell className="w-5 h-5" />
                                <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full"></span>
                            </button>
                            <button className="p-2 text-gray-400 hover:text-gray-600">
                                <Settings className="w-5 h-5" />
                            </button>
                            <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-medium">
                                张
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                <div className="flex gap-8">
                    {/* 侧边栏 */}
                    <aside className="w-64 flex-shrink-0">
                        <nav className="bg-white rounded-lg shadow-sm border sticky top-24">
                            <div className="p-4">
                                <h2 className="text-sm font-medium text-gray-500 uppercase tracking-wide">功能导航</h2>
                            </div>
                            <ul className="space-y-1 p-2">
                                {navigationItems.map((item) => {
                                    const Icon = item.icon;
                                    return (
                                        <li key={item.id}>
                                            <button
                                                onClick={() => setActiveTab(item.id)}
                                                className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors ${activeTab === item.id
                                                        ? 'bg-blue-500 text-white'
                                                        : 'text-gray-700 hover:bg-gray-100'
                                                    }`}
                                            >
                                                <Icon className="w-5 h-5" />
                                                <span>{item.label}</span>
                                            </button>
                                        </li>
                                    );
                                })}
                            </ul>

                            {/* 企业管理部分 */}
                            <div className="p-4 border-t">
                                <h2 className="text-sm font-medium text-gray-500 uppercase tracking-wide mb-3">企业档案管理</h2>
                                <div className="flex items-center justify-between mb-2">
                                    <select
                                        value={selectedCompany}
                                        onChange={(e) => setSelectedCompany(e.target.value)}
                                        className="flex-1 text-sm border border-gray-300 rounded px-2 py-1 mr-2"
                                    >
                                        <option>北京xx科技有限公司</option>
                                        <option>上海yy贸易有限公司</option>
                                        <option>深圳zz投资有限公司</option>
                                    </select>
                                    <button className="p-1 border border-gray-300 rounded hover:bg-gray-50">
                                        <Plus className="w-4 h-4" />
                                    </button>
                                </div>
                                <div className="text-sm text-gray-600">企业列表</div>
                                <div className="mt-2">
                                    <div className="text-sm font-medium">{selectedCompany}</div>
                                </div>
                            </div>
                        </nav>
                    </aside>

                    {/* 主内容区 */}
                    <main className="flex-1">
                        {renderContent()}
                    </main>
                </div>
            </div>
        </div>
    );
}

export default TaxConsultingPlatform;